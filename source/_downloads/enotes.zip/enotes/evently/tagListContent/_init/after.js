function (data) {
    $.log("evently/tagListContent/after.js" )
    $("#taglist").listview();
    return data;
}
