function(event, name, pass) {
        var target = $(event.target);
        $.log("evently/tagListContent/_init/selectors/a/click.js");
var tag = target.attr("id");
$("body").data.tagSelected = tag;
}
