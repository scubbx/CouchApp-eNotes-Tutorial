function (data) {
    $.log("evently/titleListContent/updateTitleList/after.js" )
    $("#titleslist").listview();
    $.log("after listview  ");
    return data;
}
