function(event) {
        var target = $(event.currentTarget);
        //probably currentTarget needed because this is a button
        $.log("editPage - shownote - a save -click.js ")
        $.log(event);
        $.log(target);
        var aid = target.attr("op");
        $.log("clicked - the tag is " + aid );

        $.log("editContent/_init/selectors/a[op=save]/click.js");
        $.log($("body").data);  // why is this not availalbe here?
        var docvalue= $("body").data.docEdited; //edata.docEdited;
        $.log(docvalue);
        var docid = docvalue._id,
                docrev =docvalue._rev,
                title = $('input[name=title]').val(),
                text = $('textarea#editTextField').val(),
                tags = $('input[name=tags]').val().split(" ");

        $("body").data.tagSelected=tags[0].toUpperCase();

        $.log("docid in save doc " + docid + " rev " + docrev + " title " + title);
        var document = {"_id": docid,
                "_rev": docrev,
                "type" : "note",
                "TextNote" : {"note" : {"title": title, "text" : text, "tags" : tags}}
        };
        $.log(document);
        doStoreDocument(document); //braucht alte id und rev

        $.log("editPage after store");
        $.log(document);
        $("#editContent").trigger("shownote");
        $.mobile.changePage("#editPage", "slidedown", true, true);
}
