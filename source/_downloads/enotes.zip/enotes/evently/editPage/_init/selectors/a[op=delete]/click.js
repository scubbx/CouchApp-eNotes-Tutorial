function(event) {
        var target = $(event.currentTarget);
        //probably currentTarget needed because this is a button
        $.log("editPage - shownote - a - delete -click.js ")
        $.log(event);
        $.log(target);
        var aid = target.attr("op");
        $.log("clicked - the tag is " + aid );
        $.log("editContent/_init/selectors/a[op=delete]/click.js");
        $.log($("body").data);
        var docvalue= $("body").data.docEdited;
        $.log(docvalue);
        var docid = docvalue._id,
                docrev =docvalue._rev

        $.log("docid in delete " + docid + " rev " + docrev);
        var document = {"_id": docid, "_rev": docrev};
        $.log(document);
        doDeleteDocument (document);

        $.log("editPage after delete");
        $.log(document);
}
