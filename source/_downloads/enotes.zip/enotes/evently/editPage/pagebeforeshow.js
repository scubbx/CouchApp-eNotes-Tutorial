function (data) {
        $.log("evently/editPage/pagebeforeshow.js" + data)
        $.log(data);
        $("#editContent").trigger("shownote");
        return data;
}
