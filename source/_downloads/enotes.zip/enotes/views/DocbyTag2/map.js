function(doc) {
    if (doc.TextNote.note.tags) {
        var words = doc.TextNote.note.tags;
        for (var i = 0; i < (words.length); i++) {
            var value = words[i].toUpperCase();
            emit(value, doc);
        }
    }
}
