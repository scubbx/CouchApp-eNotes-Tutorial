function(key, values) {
        return sum(values);
}
