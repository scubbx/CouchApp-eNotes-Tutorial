## eNotes CouchApp

This CouchApp represents the final product of the eNotes CouchApp tutorial. Use it as a reference or to find mistakes in your code.

Install with 
    
    couchapp push enotes

